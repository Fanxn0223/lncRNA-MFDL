====================================================================
		    
 lncRNA-MFDL                        2014/09/29
 ver1.0.0                         ICI/LIFT, China
		    	 	       
====================================================================

System Requirements
===================
Software Requirements
---------------------
The lncRNA-MFDL is supported on Linux32-bit operating systems 
    MATLAB
    Python

Hardware Requirements/Recommendations
-------------------------------------
   Intel Core i3 2100 or later for Linux 
   Color display capable of 1024 X 768 pixel resolution
   
Memory Requirements/Recommendations
-------------------------------------
lncRNA-MFDL requires approximately
100 M of available disk space on the drive or partition.

lncRNA-MFDL requires a minimum of 
2G of RAM plus additional memory.

Operation Guide
===================
1) Install  
fxn@linux$ unzip lncRNA-MFDL.zip
fxn@linux$ cd lncRNA-MFDL/bin
fxn@linux$ chmod a+x txCdsPredict
fxn@linux$ chmod a+x RNAfold
 
2) Execute in MATLAB
step1. open MATLAB and set the current directory to lncRNA-MFDL folder 
step2. add the subfolders in the lncRNA-MFDL folder to the path 
step3. run lncRNA_MFDL.p,appearing the interface of lncRNA-MFDL software
step4. input the query sequence or load the sequence file
setp5. click on 'RUN'

Results is presented in 'result_lncRNA_MFDL.txt'. 

-------------------------------------
lncRNA-MFDL depends on three programs (txCdsPredict, RNAfold and a part of CNCI) which are all 
included in the pre-compiled binary package. 
Following is the source code download links:
txCdsPredict:http://hgdownload.cse.ucsc.edu/admin/
RNAfold:http://www.tbi.univie.ac.at/RNA/index.html#download
CNCI:http://www.bioinfo.org/software/cnci

Copyright Notice
===================
Software, documentation and related materials:
Copyright (c) 2014-2016 
Key Laboratory of Information Fusion Technology(LIFT), Ministry of Education, China
School of Automation, Northwestern Polytechnical University,China
All rights reserved.
